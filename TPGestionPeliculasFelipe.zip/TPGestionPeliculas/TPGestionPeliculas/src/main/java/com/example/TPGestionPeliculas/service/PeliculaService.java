package com.example.TPGestionPeliculas.service;

import com.example.TPGestionPeliculas.exception.BusinessException;
import com.example.TPGestionPeliculas.model.Pelicula;
import com.example.TPGestionPeliculas.repository.PeliculaRepository;
import jakarta.validation.ValidationException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

import static com.example.TPGestionPeliculas.validations.PeliculaValidator.validarDocumentales;
import static com.example.TPGestionPeliculas.validations.PeliculaValidator.validarTituloDirector;

@Service
public class PeliculaService {

    @Autowired
    private PeliculaRepository repository;

    public List<Pelicula> getAllMovies() {
        return repository.findAll();
    }

    public Optional<Pelicula> savePelicula (Pelicula pelicula) throws BusinessException {
        validarTituloDirector(pelicula, repository, pelicula.getTitulo(), pelicula.getDirector());
        validarDocumentales(pelicula);
        return Optional.of(repository.save(pelicula));
    }

    public List<Pelicula> findByAnio(Integer anio){
        return repository.findByAnio(anio);
    }

    public Optional<Pelicula> findByID(Long id){
        return repository.findById(id);
    }

}
