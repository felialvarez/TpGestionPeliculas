package com.example.TPGestionPeliculas.validations;

import com.example.TPGestionPeliculas.exception.BusinessException;
import com.example.TPGestionPeliculas.model.Pelicula;
import com.example.TPGestionPeliculas.repository.PeliculaRepository;
import jakarta.validation.ValidationException;

import java.util.List;

public class PeliculaValidator {

    public static void validarDocumentales(Pelicula pelicula) throws BusinessException{
        if (pelicula.getGenero() != null &&
                pelicula.getGenero().equalsIgnoreCase("documental") &&
                pelicula.getAnio() < 1920) {
            throw new BusinessException("No se permiten documentales anteriores al año 1920.");
        }
    }

    public static void validarTituloDirector (Pelicula pelicula, PeliculaRepository repository, String titulo, String director)throws BusinessException{
    List<Pelicula> existentes = repository.findByTituloAndDirector(pelicula.getTitulo(), pelicula.getDirector());
        if (!existentes.isEmpty()) {
        throw new BusinessException("Ya existe una película con ese título y director.");
    }
    }
}
