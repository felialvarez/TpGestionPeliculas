package com.example.TPGestionPeliculas.exception;

public class BusinessException extends Throwable {
  public BusinessException(String elAniooEsIncorrecto) {
    super(elAniooEsIncorrecto);
  }
}