package com.example.TPGestionPeliculas.controller;

import com.example.TPGestionPeliculas.exception.BusinessException;
import com.example.TPGestionPeliculas.model.Pelicula;
import com.example.TPGestionPeliculas.repository.PeliculaRepository;
import com.example.TPGestionPeliculas.service.PeliculaService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/peliculas")
public class PeliculaController {

    @Autowired
    private PeliculaService peliculaService;

    @GetMapping
    public List<Pelicula> getAllMovies() {
        return peliculaService.getAllMovies();
    }

    @PostMapping
    public ResponseEntity<?> createPelicula(@Valid @RequestBody Pelicula pelicula) throws BusinessException {
        if (pelicula.getTitulo() == null) {
            return ResponseEntity.badRequest().build();
        }
        Optional<Pelicula> peliculaAux = peliculaService.savePelicula(pelicula);
        return ResponseEntity.ok(peliculaAux);
    }

    @GetMapping("/anio/{anio}")
    public ResponseEntity<List<Pelicula>> getByAnio(@PathVariable Integer anio) {

        List<Pelicula> peliculas = peliculaService.findByAnio(anio);

        return peliculas.isEmpty()
                ? ResponseEntity.noContent().build()
                : ResponseEntity.ok(peliculas);
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getById(@PathVariable Long id) {
        return peliculaService.findByID(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }




}
